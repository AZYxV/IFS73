---
name: Pull request
about: ''
title: ''
labels: ''
assignees: ''

---

<!--

Important! 

If it's a bug fix, create a pull request to master branch. 
It it's a new feature, choose develop branch. 
Be sure you also updated a documentation (README file).

-->

**Description**
A clear and concise description of what the proposed changes do.

**Related issues**
Fixes: #
