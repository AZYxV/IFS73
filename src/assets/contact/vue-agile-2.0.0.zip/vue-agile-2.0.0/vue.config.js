module.exports = {
  publicPath: '/vue-agile/',
  configureWebpack: {
    output: {
      libraryExport: 'default'
    }
  }
}
